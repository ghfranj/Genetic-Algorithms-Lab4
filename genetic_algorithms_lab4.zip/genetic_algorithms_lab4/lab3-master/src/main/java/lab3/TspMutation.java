package lab3;

import org.uncommons.watchmaker.framework.EvolutionaryOperator;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;

public class TspMutation implements EvolutionaryOperator<TspSolution> {

    private final double swapMutationProbability;
    private final double insertMutationProbability;
    private final double scrambleMutationProbability;
    private final double inversionMutationProbability;

    public TspMutation(double swapMutationProbability, double insertMutationProbability, double scrambleMutationProbability, double inversionMutationProbability) {
        this.swapMutationProbability = swapMutationProbability;
        this.insertMutationProbability = insertMutationProbability;
        this.scrambleMutationProbability = scrambleMutationProbability;
        this.inversionMutationProbability = inversionMutationProbability;
    }

    public List<TspSolution> apply(List<TspSolution> population, Random random) {
        List<TspSolution> mutatedPopulation = new ArrayList<>();

        for (TspSolution solution : population) {
            double mutationProbability = random.nextDouble();

            if (mutationProbability < swapMutationProbability) {
                mutatedPopulation.add(swapMutation(solution, random));
            } else if (mutationProbability < swapMutationProbability + insertMutationProbability) {
                mutatedPopulation.add(insertMutation(solution, random));
            } else if (mutationProbability < swapMutationProbability + insertMutationProbability + scrambleMutationProbability) {
                mutatedPopulation.add(scrambleMutation(solution, random));
            } else if (mutationProbability < swapMutationProbability + insertMutationProbability + scrambleMutationProbability + inversionMutationProbability) {
                mutatedPopulation.add(inversionMutation(solution, random));
            } else {
                mutatedPopulation.add(solution); // No mutation
            }
        }

        return mutatedPopulation;
    }

    private TspSolution swapMutation(TspSolution solution, Random random) {
        int tourSize = solution.getTourSize();
        int index1 = random.nextInt(tourSize);
        int index2 = random.nextInt(tourSize);
        while (index1 == index2) {
            index2 = random.nextInt(tourSize); // Ensure distinct indices
        }
        // Swap cities at index1 and index2
        int city1 = solution.getCity(index1);
        int city2 = solution.getCity(index2);
        solution.setCity(index1, city2);
        solution.setCity(index2, city1);
        return solution;
    }

    private TspSolution insertMutation(TspSolution solution, Random random) {
        List<Integer> tour = solution.getTour();
        int tourSize = tour.size();
        // Choose two random indices within the tour
        int index1 = random.nextInt(tourSize);
        int index2 = random.nextInt(tourSize);
        // Ensure distinct indices
        while (index1 == index2) {
            index2 = random.nextInt(tourSize);
        }
        // Remove the city at index1 and insert it at index2
        int city = tour.remove(index1);
        if (index1 < index2) {
            index2--; // Adjust index2 after removing a city
        }
        tour.add(index2, city);

        return solution;
    }


    private TspSolution scrambleMutation(TspSolution solution, Random random) {
        List<Integer> tour = solution.getTour();
        int tourSize = tour.size();

        // Choose two random indices within the tour
        int index1 = random.nextInt(tourSize);
        int index2 = random.nextInt(tourSize);

        // Ensure distinct indices
        while (index1 == index2) {
            index2 = random.nextInt(tourSize);
        }

        // Ensure index1 < index2
        if (index1 > index2) {
            int temp = index1;
            index1 = index2;
            index2 = temp;
        }

        // Shuffle the subset of cities between index1 and index2 (inclusive)
        List<Integer> subset = tour.subList(index1, index2 + 1);
        Collections.shuffle(subset, random);

        // Update the tour with the shuffled subset
        for (int i = 0; i < subset.size(); i++) {
            solution.setCity(index1 + i, subset.get(i));
        }

        return solution;
    }


    private TspSolution inversionMutation(TspSolution solution, Random random) {
        List<Integer> tour = solution.getTour();
        int tourSize = tour.size();

        // Choose two random indices within the tour
        int index1 = random.nextInt(tourSize);
        int index2 = random.nextInt(tourSize);

        // Ensure distinct indices
        while (index1 == index2) {
            index2 = random.nextInt(tourSize);
        }

        // Ensure index1 < index2
        if (index1 > index2) {
            int temp = index1;
            index1 = index2;
            index2 = temp;
        }

        // Reverse the subset of cities between index1 and index2 (inclusive)
        List<Integer> subset = tour.subList(index1, index2 + 1);
        Collections.reverse(subset);

        // Update the tour with the reversed subset
        for (int i = 0; i < subset.size(); i++) {
            solution.setCity(index1 + i, subset.get(i));
        }

        return solution;
    }

}

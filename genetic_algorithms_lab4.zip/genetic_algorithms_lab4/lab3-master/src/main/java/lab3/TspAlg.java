package lab3;

import org.uncommons.maths.random.Probability;
import org.uncommons.watchmaker.framework.*;
import org.uncommons.watchmaker.framework.operators.EvolutionPipeline;
import org.uncommons.watchmaker.framework.selection.TournamentSelection;
import org.uncommons.watchmaker.framework.termination.GenerationCount;

import java.util.ArrayList;
import java.util.Random;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
public class TspAlg {
    public static int[] readGridDimensions(String filePath) throws IOException {
        BufferedReader reader = new BufferedReader(new FileReader(filePath));
        int maxX = Integer.MIN_VALUE;
        int maxY = Integer.MIN_VALUE;
        int numCities = 0;
        String line;
        boolean dataStarted = false;
        while ((line = reader.readLine()) != null) {
            if (line.startsWith("NODE_COORD_SECTION")) {
                dataStarted = true;
                continue;
            }
            if (line.startsWith("EOF")) {
                break;
            }
            if (dataStarted) {
                String[] tokens = line.trim().split("\\s+");
                int x = Integer.parseInt(tokens[1]);
                int y = Integer.parseInt(tokens[2]);
                maxX = Math.max(maxX, x);
                maxY = Math.max(maxY, y);
                numCities = Math.max(numCities, Integer.parseInt(tokens[0]));
            }
        }
        reader.close();
        return new int[]{numCities, maxX, maxY};
    }

    public static void main(String[] args) {
        String problem = "experiments/xql662.tsp"; // name of problem or path to input file
        double swapMutationProbability = 0.01,
                insertMutationProbability = 0.01,
                scrambleMutationProbability = 0.5,
                inversionMutationProbability = 0.1;
        int populationSize = 10; // size of population
        int generations = 5000; // number of generations
        Random random = new Random(); // random
        double best_fit = run_algorithm(
                new double[]{swapMutationProbability, insertMutationProbability,
                        scrambleMutationProbability, inversionMutationProbability},
        problem,
        populationSize,
        generations

        );
    }
    public static double run_algorithm(
           double[] parameters,
           String problem,
           int populationSize,
           int generations
    ) {
        double swapMutationProbability = parameters[0],
                insertMutationProbability = parameters[1],
                scrambleMutationProbability = parameters[2],
                inversionMutationProbability = parameters[3];
        Random random = new Random(); // random
        int numCities = 0;
        try {
            numCities = readGridDimensions(problem)[0];
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        CandidateFactory<TspSolution> factory = new TspFactory(numCities); // generation of solutions

        ArrayList<EvolutionaryOperator<TspSolution>> operators = new ArrayList<EvolutionaryOperator<TspSolution>>();
        operators.add(new TspCrossover()); // Crossover
        operators.add(new TspMutation(
                swapMutationProbability,
                insertMutationProbability,
                scrambleMutationProbability,
                inversionMutationProbability)); // Mutation
        EvolutionPipeline<TspSolution> pipeline = new EvolutionPipeline<TspSolution>(operators);

        SelectionStrategy<Object> selection = new TournamentSelection(new Probability(0.95)); // Selection operator

        FitnessEvaluator<TspSolution> evaluator = null; // Fitness function
        try {
            evaluator = new TspFitnessFunction(problem);
        } catch (IOException e) {
            System.out.println(e.getMessage());
            throw new RuntimeException(e);
        }
        TspSolution best;

        EvolutionEngine<TspSolution> algorithm = new SteadyStateEvolutionEngine<TspSolution>(
                factory, pipeline, evaluator, selection, populationSize, false, random);
        final double[] finalFit = {0};
        algorithm.addEvolutionObserver(new EvolutionObserver() {
            public void populationUpdate(PopulationData populationData) {
                double bestFit = populationData.getBestCandidateFitness();
                finalFit[0] = bestFit;
                System.out.println("Generation " + populationData.getGenerationNumber() + ": " + bestFit);
                TspSolution best = (TspSolution)populationData.getBestCandidate();
                System.out.println("\tBest solution = " + best.toString());
            }
        });

        TerminationCondition terminate = new GenerationCount(generations);
        algorithm.evolve(populationSize, 1, terminate);
        System.out.println(numCities + " cities, best fit: " + finalFit[0]);
        return finalFit[0];
    }
}
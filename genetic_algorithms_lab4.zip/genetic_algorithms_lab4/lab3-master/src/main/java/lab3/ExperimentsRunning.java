package lab3;

import org.uncommons.maths.random.Probability;
import org.uncommons.watchmaker.framework.*;
import org.uncommons.watchmaker.framework.operators.EvolutionPipeline;
import org.uncommons.watchmaker.framework.selection.RouletteWheelSelection;
import org.uncommons.watchmaker.framework.selection.TournamentSelection;
import org.uncommons.watchmaker.framework.termination.GenerationCount;

import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Random;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class ExperimentsRunning {
    public static void main(String[] args) {
        File folder = new File("experiments");
        File[] files = folder.listFiles((dir, name) -> name.toLowerCase().endsWith(".tsp"));

        if (files == null || files.length == 0) {
            System.out.println("No TSP files found in the 'experiments' folder.");
            return;
        }

        try (FileWriter writer = new FileWriter("experiments_results.txt")) {
            for (File file : files) {
                String problem = file.getName();
                int[] gridDimensions = TspAlg.readGridDimensions(file.getPath());
                int numCities = gridDimensions[0];

                writer.write("TSP File: " + problem + "\n");
                writer.write("Number of Cities: " + numCities + "\n");
                writer.write("Optimal Parameters and Fitness:\n");

                // Run the algorithm with different parameter values
                double[] mutationProbabilities = {0.01, 0.05, 0.1};
                int[] populationSizes = {10, 20, 30};
                int[] generationsValues = {100, 1000, 1000};

                double bestFitness = Double.MAX_VALUE;
                double[] bestParameters = null;
                int bestPopulationSize = 0;
                int bestGenerations = 0;

                for (double swapMutationProbability : mutationProbabilities) {
                    for (double insertMutationProbability : mutationProbabilities) {
                        for (double scrambleMutationProbability : mutationProbabilities) {
                            for (double inversionMutationProbability : mutationProbabilities) {
                                for (int populationSize : populationSizes) {
                                    for (int generations : generationsValues) {
                                        double[] parameters = {swapMutationProbability, insertMutationProbability,
                                                scrambleMutationProbability, inversionMutationProbability};
                                        double result = TspAlg.run_algorithm(parameters, "experiments/" + problem, populationSize, generations);
                                        if (result < bestFitness) {
                                            bestFitness = result;
                                            bestParameters = parameters;
                                            bestPopulationSize = populationSize;
                                            bestGenerations = generations;
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                // Record the parameter values and the fitness of the optimal solution
                writer.write("Mutation Probabilities: " + Arrays.toString(bestParameters) + "\n");
                writer.write("Population Size: " + bestPopulationSize + "\n");
                writer.write("Generations: " + bestGenerations + "\n");
                writer.write("Fitness of Optimal Solution: " + bestFitness + "\n");
                writer.write("\n");
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}


package lab3;

import javafx.util.Pair;
import org.uncommons.watchmaker.framework.FitnessEvaluator;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.List;

public class TspFitnessFunction implements FitnessEvaluator<TspSolution> {

    private final double[][] distances;
    private final int[] gridDimentions;
    private final Pair<Integer, Integer>[] citiesCoord;

    public TspFitnessFunction(String filePath) throws IOException {
        gridDimentions = readGridDimensions(filePath);
        citiesCoord = getCitiesCoord(filePath, gridDimentions[0]);
        distances = calculateDistances(citiesCoord);
    }
    public static int[] readGridDimensions(String filePath) throws IOException {
        BufferedReader reader = new BufferedReader(new FileReader(filePath));
        int maxX = Integer.MIN_VALUE;
        int maxY = Integer.MIN_VALUE;
        int numCities = 0;
        String line;
        boolean dataStarted = false;
        while ((line = reader.readLine()) != null) {
            if (line.startsWith("NODE_COORD_SECTION")) {
                dataStarted = true;
                continue;
            }
            if (line.startsWith("EOF")) {
                break;
            }
            if (dataStarted) {
                String[] tokens = line.trim().split("\\s+");
                int x = Integer.parseInt(tokens[1]);
                int y = Integer.parseInt(tokens[2]);
                maxX = Math.max(maxX, x);
                maxY = Math.max(maxY, y);
                numCities = Math.max(numCities, Integer.parseInt(tokens[0]));
            }
        }
        reader.close();
        return new int[]{numCities, maxX, maxY};
    }
    public static Pair<Integer, Integer>[] getCitiesCoord(String filePath, int numCities) throws IOException {
        Pair<Integer, Integer>[] citiesCoord = new Pair[numCities];
        BufferedReader reader = new BufferedReader(new FileReader(filePath));
        int maxX = Integer.MIN_VALUE;
        int maxY = Integer.MIN_VALUE;
        String line;
        boolean dataStarted = false;
        while ((line = reader.readLine()) != null) {
            if (line.startsWith("NODE_COORD_SECTION")) {
                dataStarted = true;
                continue;
            }
            if (line.startsWith("EOF")) {
                break;
            }
            if (dataStarted) {
                String[] tokens = line.trim().split("\\s+");
                int i = Integer.parseInt(tokens[1]);
                int j = Integer.parseInt(tokens[2]);
                Pair<Integer, Integer> p = new Pair<>(i,j);
                citiesCoord[Integer.parseInt(tokens[0])-1] = p;
            }
        }
        reader.close();
        return citiesCoord;
    }
    private double[][] calculateDistances(Pair<Integer, Integer>[] citiesCoord) {
        int numCities = citiesCoord.length;
        double[][] distances = new double[numCities][numCities];

        // Calculate distances between all pairs of cities
        for (int city1 = 0; city1 < numCities; city1++) {
            for (int city2 = 0; city2 < numCities; city2++) {
                int x1 = citiesCoord[city1].getKey();
                int y1 = citiesCoord[city1].getValue();
                int x2 = citiesCoord[city2].getKey();
                int y2 = citiesCoord[city2].getValue();
                double distance = Math.round(Math.sqrt(Math.pow(x2 - x1, 2) + Math.pow(y2 - y1, 2)));
                distances[city1][city2] = distance;
            }
        }
        return distances;
    }



    public double getFitness(TspSolution candidate, List<? extends TspSolution> population) {
        List<Integer> route = candidate.getTour(); // Get the route from the candidate solution
        double totalDistance = 0.0;

        // Calculate total distance traveled along the route
        for (int i = 0; i < route.size() - 1; i++) {
            int city1 = route.get(i);
            int city2 = route.get(i + 1);
            totalDistance += distances[city1][city2];
        }

        // Add distance from the last city back to the starting city
        int lastCity = route.get(route.size() - 1);
        int firstCity = route.get(0);
        totalDistance += distances[lastCity][firstCity];

        return totalDistance;
    }





    public boolean isNatural() {
        return false; // It's a minimization problem
    }
}

package lab3;

import org.uncommons.watchmaker.framework.operators.AbstractCrossover;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;

public class TspCrossover extends AbstractCrossover<TspSolution> {

    public TspCrossover() {
        super(1); // Number of parents required for crossover (always 2 for TSP)
    }

    protected List<TspSolution> mate(TspSolution parent1, TspSolution parent2, int numberOfCrossoverPoints, Random random) {
        int tourSize = parent1.getTourSize();
        List<Integer> child1 = new ArrayList<>(Collections.nCopies(tourSize, -1)); // Initialize child with -1
        List<Integer> child2 = new ArrayList<>(Collections.nCopies(tourSize, -1)); // Initialize child with -1

        // Generate random crossover points
        int crossoverPoint1 = random.nextInt(tourSize);
        int crossoverPoint2 = random.nextInt(tourSize);

        // Ensure crossover points are different
        while (crossoverPoint1 == crossoverPoint2) {
            crossoverPoint2 = random.nextInt(tourSize);
        }

        // Ensure crossoverPoint1 < crossoverPoint2
        if (crossoverPoint1 > crossoverPoint2) {
            int temp = crossoverPoint1;
            crossoverPoint1 = crossoverPoint2;
            crossoverPoint2 = temp;
        }

        // Transfer genes between crossover points from parent1 to child1 and from parent2 to child2
        for (int i = crossoverPoint1; i <= crossoverPoint2; i++) {
            int city = parent1.getCity(i);
            child1.set(i, city);

            city = parent2.getCity(i);
            child2.set(i, city);
        }

        // Transfer remaining genes from parent2 to child1 and from parent1 to child2
        int indexChild1 = crossoverPoint2 + 1;
        int indexChild2 = crossoverPoint2 + 1;
        for (int i = 0; i < tourSize; i++) {
            int city = parent2.getCity(i);
            if (!child1.contains(city)) {
                child1.set(indexChild1 % tourSize, city);
                indexChild1++;
            }

            city = parent1.getCity(i);
            if (!child2.contains(city)) {
                child2.set(indexChild2 % tourSize, city);
                indexChild2++;
            }
        }

        // Create child solutions
        TspSolution childSolution1 = new TspSolution(child1);
        TspSolution childSolution2 = new TspSolution(child2);

        List<TspSolution> children = new ArrayList<>();
        children.add(childSolution1);
        children.add(childSolution2);

        return children;
    }
}

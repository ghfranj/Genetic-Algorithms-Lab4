package lab3;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class TspSolution {
    private List<Integer> tour;

    public TspSolution(List<Integer> tour) {
        this.tour = new ArrayList<>(tour);
    }

    public List<Integer> getTour() {
        return tour;
    }

    public int getTourSize() {
        return tour.size();
    }

    public int getCity(int index) {
        return tour.get(index);
    }

    public void setCity(int index, int city) {
        tour.set(index, city);
    }

    public void shuffleTour() {
        Collections.shuffle(tour);
    }

    @Override
    public String toString() {
        StringBuilder pathBuilder = new StringBuilder();
        for (int i = 0; i < tour.size(); i++) {
            if (i > 0) {
                pathBuilder.append("->");
            }
            pathBuilder.append(tour.get(i));
        }
        return pathBuilder.toString();
    }
}

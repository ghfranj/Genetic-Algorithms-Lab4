package lab3;

import org.uncommons.watchmaker.framework.factories.AbstractCandidateFactory;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;

public class TspFactory extends AbstractCandidateFactory<TspSolution> {
    private final int numCities;

    public TspFactory(int numCities) {
        this.numCities = numCities;
    }

    @Override
    public TspSolution generateRandomCandidate(Random random) {
        List<Integer> cities = new ArrayList<>();
        for (int i = 0; i < numCities; i++) {
            cities.add(i);
        }
        Collections.shuffle(cities, random);
        return new TspSolution(cities);
    }
}
